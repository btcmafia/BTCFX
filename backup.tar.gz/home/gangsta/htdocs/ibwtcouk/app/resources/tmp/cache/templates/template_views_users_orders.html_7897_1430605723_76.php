<h2>Pending Orders</h2>

<?php
echo $this->_render('element', 'orders');
?>
