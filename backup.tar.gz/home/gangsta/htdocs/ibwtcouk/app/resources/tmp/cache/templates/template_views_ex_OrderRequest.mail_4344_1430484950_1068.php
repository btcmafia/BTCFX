<div style="background-color:#eeeeee;height:50px;padding-left:20px;padding-top:10px">
	<img src="https://<?php echo $h(COMPANY_URL); ?>/img/<?php echo $h(COMPANY_URL); ?>.gif" alt="<?php echo $h(COMPANY_URL); ?>">
</div>
<h4>Hi <?php echo $h($user['username']); ?>,</h4>
<p>Your order is placed at <?php echo $h(COMPANY_URL); ?>.</p>
<table border="1">
	<tr>
		<td>Action</td>
		<td>Amount</td>
		<td>Price</td>
		<td>Total Amount</td>
	</tr>
	<tr>
		<?php if($order['Action']=="Buy"){?>
		<td><?php echo $h($order['Action']); ?> <?php echo $h($order['FirstCurrency']); ?> with <?php echo $h($order['SecondCurrency']); ?></td>
		<?php }else{?>
		<td><?php echo $h($order['Action']); ?> <?php echo $h($order['FirstCurrency']); ?> get <?php echo $h($order['SecondCurrency']); ?></td>		
		<?php } ?>
		<td><?php echo $h(number_format($order['Amount'],8)); ?></td>
		<td><?php echo $h(number_format($order['PerPrice'],8)); ?></td>
		<td><?php echo $h(number_format($order['PerPrice']*$order['Amount'],8)); ?></td>		
	</tr>
</table>
<p>To view your order please sign in to https://ibwt.co.uk. </p>
<p>If you did not place this order then please contact us at support@ibwt.co.uk or via telephone 07914 446125 as soon as possible.</p>

<p>Thank you,</p>
<p>Support</p>