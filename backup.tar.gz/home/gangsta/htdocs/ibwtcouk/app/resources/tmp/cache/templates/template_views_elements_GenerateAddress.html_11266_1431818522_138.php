<?php echo $this->form->create(); ?>

 <?php echo $this->form->submit('Generate New Address', array('name' => 'newaddress')); ?>

<?php echo $this->form->end(); ?>
