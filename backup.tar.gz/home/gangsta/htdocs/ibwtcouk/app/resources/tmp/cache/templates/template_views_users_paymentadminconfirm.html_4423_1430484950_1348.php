<?php if(count($transaction)!=0){?>
<h4>Withdraw <?php echo $h(abs($transaction['Amount'])); ?> <?php echo $h($currency); ?> to <?php echo $h($transaction['address']); ?> by user <?php echo $h($username); ?></h4>
<div class="row">
	<div class="col-md-6 well" >
	<form action="/users/payment/" method="post" id="PaymentForm" class="form-group">
	<input type="hidden" name="username" id="Username" value="<?php echo $h($transaction['username']); ?>" class="form-control"/>
	<input type="hidden" name="currency" id="Currency" value="<?php echo $h($currency); ?>" class="form-control"/>	
	<input type="hidden" id="verify" value="<?php echo $h($transaction['verify.payment']); ?>" name="verify" class="form-control">
	<?php echo $this->form->field('admin', array('type' => 'text', 'label'=>'Admin Username', 'placeholder'=>'username','class'=>'form-control')); ?><br>
	<?php echo $this->form->field('password', array('type' => 'password', 'label'=>'Password', 'placeholder'=>'password','class'=>'form-control')); ?><br>
	<?php echo $this->form->field('totp', array('type' => 'password', 'label'=>'Google TOTP', 'placeholder'=>'Google TOTP','class'=>'form-control','maxlength'=>6)); ?><br>
	<h4><?php 
		print_r($txmessage);	
	?></h4>

	<input type="submit" value="Confirm <?php echo $h($currency); ?> Withdrawal" class="btn btn-success" id="PaymentConfirm" onClick="document.getElementById('PaymentConfirm').disabled = true;$('#PaymentForm').submit();"> 
	</form>
	</div>
</div>
<?php }?>
