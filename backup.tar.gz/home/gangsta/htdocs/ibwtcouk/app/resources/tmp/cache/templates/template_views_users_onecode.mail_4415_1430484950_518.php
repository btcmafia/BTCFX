<?php
			$response = file_get_contents("http://ipinfo.io/{$_SERVER['REMOTE_ADDR']}");
			$details = json_decode($response);
			if($details->tor) {
				$tor = "Login is disabled from TOR!";
			}
?>
<p>Use this "<strong>Login Email Password</strong>" to sign in to <?php echo $h($COMPANY_URL); ?></p>
<p>
Login: <?php echo $h($username); ?><br>
Login Email Password: <strong style="font-size:24px;font-weight:bold "><?php echo $h($oneCode); ?></strong><br>
IP: <?php echo $h($_SERVER['REMOTE_ADDR']); ?><br>
<?php echo $h($tor); ?><br>
Date and time: <?php echo $h(gmdate('Y-m-d H:i:s',time())); ?>
</p>