<div class="col-md-12" id="Graph" style="text-align:center;display:none" >
		<div class="panel panel-default">
			<div class="panel panel-heading">
				<h2 class="panel-title" style="cursor:pointer;font-weight:bold" onclick="document.getElementById('Graph').style.display='none';">Graph
					<i class="glyphicon glyphicon-remove"></i>
				</h2>
			</div>
			<div style="padding-bottom:15px;padding-left:10px;margin-top:-20px">
				<img src="/documents/<?php echo $h($first_curr); ?>_<?php echo $h($second_curr); ?>.png">
			</div>
			<div style="padding-bottom:15px;padding-left:10px;margin-top:-20px">
				<img src="/documents/<?php echo $h($first_curr); ?>_<?php echo $h($second_curr); ?>-T.png">
			</div>
		</div>
	</div>
