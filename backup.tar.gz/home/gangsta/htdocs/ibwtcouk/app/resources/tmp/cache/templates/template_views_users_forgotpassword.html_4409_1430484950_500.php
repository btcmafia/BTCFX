<div class="row container-fluid">
	<div class="col-md-6" >
		<h4>Forgot password</h4>
		<?php echo $this->form->create("",array('url'=>'/users/forgotpassword','class'=>'form-group has-error')); ?>
		<?php echo $this->form->field('email', array('type' => 'text', 'label'=>'Your email','placeholder'=>'name@yourdomain.com','class'=>'form-control' )); ?>					<br>
		<?php echo $h($msg); ?><br>
		<?php echo $this->form->submit('Send password reset link' ,array('class'=>'btn btn-primary')); ?>					
		<?php echo $this->form->end(); ?>
	</div>
</div>