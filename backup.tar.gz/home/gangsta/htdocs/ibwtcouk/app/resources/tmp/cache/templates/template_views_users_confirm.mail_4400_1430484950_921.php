<div style="background-color:#eeeeee;height:50px;padding-left:20px;padding-top:10px">
	<img src="https://<?php echo $h(COMPANY_URL); ?>/img/<?php echo $h(COMPANY_URL); ?>.gif" alt="<?php echo $h(COMPANY_URL); ?>">
</div>
<h4>Hi <?php echo $h($name); ?>,</h4>

<p>Please confirm your email address associated at <?php echo $h(COMPANY_URL); ?> by clicking the following link:</p>

<p><a href="https://<?php echo $h($_SERVER['HTTP_HOST']); ?>/users/confirm/<?php echo $h($email); ?>/<?php echo $h($verification); ?>">
https://<?php echo $h($_SERVER['HTTP_HOST']); ?>/users/confirm/<?php echo $h($email); ?>/<?php echo $h($verification); ?></a></p>

<p>Or use this confirmation code: <?php echo $h($verification); ?> for your email address: <?php echo $h($email); ?> on the page 
https://<?php echo $h($_SERVER['HTTP_HOST']); ?>/users/email</p>

</p>

<p>Thanks,<br>
<?php echo $h(NOREPLY); ?></p>

<p>P.S. Please do not reply to this email. </p>
<p>This email was sent to you as you tried to register on <?php echo $h(COMPANY_URL); ?> with the email address. 
If you did not register, then you can delete this email.</p>
<p>We do not spam. </p>
