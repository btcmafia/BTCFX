<div class="col-md-6">
	<h3>Email Verification:</h3>
	<?php echo $msg;?>
	<?php echo $this->form->create("",array('url'=>'/users/confirm/')); ?>
	<?php echo $this->form->field('email', array('label'=>'Email','placeholder'=>'name@youremail.com','class'=>'form-control' )); ?>
	<?php echo $this->form->field('verified', array('type' => 'text', 'label'=>'Verification code','placeholder'=>'50d54d309d5d0c3423000000','class'=>'form-control' )); ?><br>
	<?php echo $this->form->submit('Verify',array('class'=>'btn btn-primary')); ?>
	<?php echo $this->form->end(); ?>
	<p>Please check your spam folder too while checking your inbox!</p>
</div>