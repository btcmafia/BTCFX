<div style="background-color:#eeeeee;height:50px;padding-left:20px;padding-top:10px">
	<img src="https://<?php echo $h(COMPANY_URL); ?>/img/<?php echo $h(COMPANY_URL); ?>.gif" alt="<?php echo $h(COMPANY_URL); ?>">
</div>
<h4>Hi <?php echo $h($data['username']); ?>,</h4>
<p>You have requested to withdraw <strong><?php echo $h(abs($data['Amount'])); ?> <?php echo $h($data['Currency']); ?></strong> from <?php echo $h(COMPANY_URL); ?>.</p>
<p>Click on the link below to confirm the transfer. </p>
<p>If you did not authorize this withdrawal to the address: <strong><?php echo $h($data['address']); ?></strong> please <strong style="color:#FF0000">do not</strong> click on the link.</p>
<a href="https://<?php echo $h(COMPANY_URL); ?>/in/paymentconfirm/<?php echo $h($data['Currency']); ?>/<?php echo $h($data['verify.payment']); ?>">https://<?php echo $h(COMPANY_URL); ?>/in/paymentconfirm/<?php echo $h($data['Currency']); ?>/<?php echo $h($data['verify.payment']); ?></a>

<p>You will be asked for your main password on the page following the link to authorize the transfer. This is an added security feature we employ to secure your coins from hackers / spammers.</p>

<p>Thanks,<br>
<?php echo $h(NOREPLY); ?></p>

<p>P.S. Please do not reply to this email. </p>
<p>This email was sent to you as you tried to withdraw BTC from <?php echo $h(COMPANY_URL); ?> with the email address. 
<p>We do not spam. </p>
