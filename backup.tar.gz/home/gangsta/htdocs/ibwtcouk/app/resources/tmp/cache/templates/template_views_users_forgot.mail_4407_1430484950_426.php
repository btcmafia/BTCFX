<div style="background-color:#eeeeee;height:50px;padding-left:20px;padding-top:10px">
	<img src="https://<?php echo $h(COMPANY_URL); ?>/img/<?php echo $h(COMPANY_URL); ?>.gif" alt="<?php echo $h(COMPANY_URL); ?>">
</div>
<p>Please click on this link to change the password!</p>
<p><a href="https://<?php echo $h($_SERVER['HTTP_HOST']); ?>/users/changepassword/<?php echo $h($key); ?>">https://<?php echo $h($_SERVER['HTTP_HOST']); ?>/users/changepassword/<?php echo $h($key); ?></a></p>

<p>Thank you,</p>
<p>Support</p>

