<?php
namespace app\models;

class Requests extends \lithium\data\Model {
}
?>