<?php
namespace app\models;

class Queries extends \lithium\data\Model {
}
?>