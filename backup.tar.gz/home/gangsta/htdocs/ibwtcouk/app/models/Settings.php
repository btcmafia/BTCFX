<?php
namespace app\models;

class Settings extends \lithium\data\Model {
}
?>