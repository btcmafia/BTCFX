<?php
namespace app\models;

class Orders extends \lithium\data\Model {
}
?>