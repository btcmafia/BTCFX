<?php
namespace app\models;

class Parameters extends \lithium\data\Model {
}
?>