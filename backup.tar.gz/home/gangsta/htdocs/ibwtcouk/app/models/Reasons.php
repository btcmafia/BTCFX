<?php
namespace app\models;

class Reasons extends \lithium\data\Model {
}
?>