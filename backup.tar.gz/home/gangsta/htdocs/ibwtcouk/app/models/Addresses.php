<?php
namespace app\models;

class Addresses extends \lithium\data\Model {
}
?>
