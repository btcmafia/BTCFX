<?php
namespace app\models;

class Logins extends \lithium\data\Model {
}
?>