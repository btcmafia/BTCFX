<?php
namespace app\models;

class Pages extends \lithium\data\Model {
}
?>