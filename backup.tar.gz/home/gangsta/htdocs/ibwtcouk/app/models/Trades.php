<?php
namespace app\models;

class Trades extends \lithium\data\Model {
}
?>