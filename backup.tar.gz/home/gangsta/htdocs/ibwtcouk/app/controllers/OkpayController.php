<?php
namespace app\controllers;
use lithium\storage\Session;
use app\models\Users;
use app\models\Details;

class OkpayController extends \lithium\action\Controller {

	public function index(){

	}
}
?>