<h3>News</h3>
<ul>
	<li><a href="/files/News Release 25-02-14.pdf">Commission Fees Reduced to 0.3%</a></li>
	<li><a href="/files/News Release 10-02-14.pdf">MtGox Problems Are Not Our Problems</a></li>
	<li><a href="/files/News Release 30-01-14.pdf">Bank Wire Transfers for USD, CAD, Euro and GBP.</a></li>
	<li><a href="/files/News Release 07-01-14.pdf">IBWT adds bank withdrawals.</a></li>
	<li><a href="/files/News Release 19-11-13.pdf">Re-Launch &amp; Alternative Funding.</a></li>
	<li><a href="/files/News Release 17-10-13.pdf">Change of Bank notice.</a></li>
	<li><a href="/files/News Release 14-10-13.pdf">API released, Resources Added and Media Recruitment.</a></li>
	<li><a href="/files/News Release 27-09-13 (b).pdf">Concerning the state of MSB and EMI registration.</a> (30<sup>th</sup> August, 2013)</li>
	<li><a href="/files/News Release 27-09-13.pdf">Launching on 30th September 2013</a></li>
</ul>