<h2>Sell Shares</h2>
<div class="col-sm-12 col-md-12">
<p>You can sell your company shares through IBWT trade platform for BTC</p>
<h4>How it works?</h4>
<ul>
	<li>Setup you company on IBWT</li>
	<li>Create profile, pitch</li>
	<li>Get verified</li>
	<li>List total shares available</li>
	<li>List shares available for sale</li>
	<li>List price in BTC/share</li>
</ul>
<p>We will list all the shares available for sale in a trade window for our users to buy!</p>
<h4>Ready!</h4>
<p><a href="/users/addcompany">Click here to start</a></p>
</div>
