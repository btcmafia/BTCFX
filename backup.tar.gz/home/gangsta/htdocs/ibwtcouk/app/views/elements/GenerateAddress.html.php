<?=$this->form->create(); ?>

 <?=$this->form->submit('Generate New Address', array('name' => 'newaddress'));?>

<?=$this->form->end();?>
