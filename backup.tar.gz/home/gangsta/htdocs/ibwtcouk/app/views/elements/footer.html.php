<div class="clear"></div>

	<h4 class="nav navbar-nav">
&copy; Bitcoins UK &amp; IBWT JD Ltd. All rights reserved. </h4>
<div class="clear"></div>
	<ul class="nav navbar-nav" style="font-size:11px">
		<li><a href="/company/contact">Contact</a></li>		
		<li><a href="/company/aboutus">About</a></li>	
  <li><a href="http://blog.ibwt.co.uk/">Blog</a></li>	
		<li><a href="/company/riskmanagement">Risk</a></li>				
		<li><a href="/company/verification">Verification</a></li>						
		<li><a href="/company/privacy">Privacy</a></li>		
		<li><a href="/company/termsofservice">Terms</a></li>				
		<li><a href="/company/legal">Legal</a></li>		
		<li><a href="/company/FAQ">FAQ</a></li>				
		<li><a href="/company/funding">Funding</a></li>						
		<li><a href="/company/sellshares">Shares</a></li>						
		<li><a href="/okpay">OKPAY</a></li>													
<!--		<li><a href="/egopay">EGOPAY</a></li>															-->
		<li><a href="/API">API</a></li>								
<!--		<li><a href="/MAPI">Merchant API</a></li>										-->
		<li><a href="/company/resources">Resources</a></li>								
	</ul>
	<p class="nav navbar-nav footer-para" >
	<!--	IBWT is a trading name of <strong>IBWT JD Ltd</strong>. Registered in England and Wales. 
		Registered office: Plymouth, PL2 2AR. Company no: 8554667. 
		Registered VAT no: 165221136. 
		Registered Information Commissioner no: ZA007784.
	-->
</p>
