<a class="navbar-brand" href="/"><img id="logo" src="/img/logo.jpg" alt="Bitcoins UK Exchange" title="Bitcoins UK Exchange"></a> 

