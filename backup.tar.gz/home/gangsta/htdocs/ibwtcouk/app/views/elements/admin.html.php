<h4>Admin functions</h4>
<div class="btn-toolbar" role="toolbar">
	<div id="Adminbar" class="btn-group btn-group-xs"> 
		<a type="button" class="btn btn-default" href="/Admin/index" >Summary</a>
		<a type="button" class="btn btn-default" href="/Admin/commission" >Commission</a>		
	</div>
	<div id="Adminbar" class="btn-group btn-group-xs"> 	
		<a type="button" class="btn btn-default" href="/Admin/approval">Approval</a>
		<a type="button" class="btn btn-default" href="/Admin/transactions">Deposits</a>
		<a type="button" class="btn btn-default" href="/Admin/withdrawals">Withdrawals</a>
		<a type="button" class="btn btn-default" href="/Admin/user">User</a>
		<a type="button" class="btn btn-default" href="/Admin/company">Company</a>		
	</div>
	<div id="Adminbar" class="btn-group btn-group-xs"> 
		<a type="button" class="btn btn-default" href="/Admin/bitcointransaction">BTC</a>
		<a type="button" class="btn btn-default" href="/Admin/litecointransaction">LTC</a>
		<a type="button" class="btn btn-default" href="/Admin/greencointransaction">XGC</a>
	</div>
	<div id="Adminbar" class="btn-group btn-group-xs"> 	
		<a type="button" class="btn btn-default" href="/Admin/orders">Orders</a>						
		<a type="button" class="btn btn-default" href="/Admin/api">API</a>
		<a type="button" class="btn btn-default" href="/Admin/map">Map</a>
		<a type="button" class="btn btn-default" href="/Admin/hard">Hard</a>
	</div>			
	<div id="Adminbar" class="btn-group btn-group-xs"> 	
		<a type="button" class="btn btn-default" href="/Admin/pages">Meta</a>						
		<a type="button" class="btn btn-default" href="/Admin/trades">Trades</a>								
	</div>			
	<div id="Adminbar" class="btn-group btn-group-xs"> 	
		<a type="button" class="btn btn-default" href="/Admin/down" class="tooltip-y"  rel="tooltip-y" data-placement="top" title="Danger! All users will be logged out and not able to sign in too... You will have to call Nilam to start it!"><i class="glyphicon glyphicon-off"></i></a>
	</div> 
</div>