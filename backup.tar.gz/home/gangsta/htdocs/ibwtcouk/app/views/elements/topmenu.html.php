<?php
use lithium\storage\Session;

?>

<ul class="nav nav-tabs">

<?php 
	$user = Session::read('default');
	if ($user!=""){		
 ?>

 <li><a href="/trade/x/btc_dct">Trade</a></li>
 <li><a href="/in/accounts/">Account Balances</a></li>
 <li><a href="/in/transactions/">Transactions</a></li>
 <li><a href="/in/orders/">Open Orders</a></li>
 <li><a href="/in/deposit/">Deposit</a></li>
 <li><a href="/in/withdraw/">Withdraw</a></li>
 <li><a href="/in/settings/">Settings</a></li>

<?php  } else { ?>

<!-- <li><a href="/company/about/">About</a></li>-->
 <li><a href="/login/">Sign In</a></li>
 <li><a href="/register/">Register</a></li>
<!-- <li><a href="/company/faq/">FAQs</a></li>-->

<?php } ?>

 </ul>

