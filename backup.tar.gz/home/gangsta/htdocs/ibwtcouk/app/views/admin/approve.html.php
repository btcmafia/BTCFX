<div class="well" style="text-align:center ">
<img src="/documents/<?=$imagename_utility?>"><br>
<a href="/documents/<?=$imagename_utility?>" target="_blank">Download and view!</a>
<br>
<a href="/Admin/approve/<?=$media?>/<?=$id?>/Approve" class="btn btn-primary">Approve</a>
<a href="/Admin/approve/<?=$media?>/<?=$id?>/Reject" class="btn btn-warning">Reject</a>
<a href="#" onclick="javascript:window.close();" class="btn">Close</a>
</div>