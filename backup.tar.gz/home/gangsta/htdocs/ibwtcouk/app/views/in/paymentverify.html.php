<h2>Email Authorisation Required</h2>
<div class="alert alert-dismissible alert-warning">
<p>We have sent an email to your registered email address for verifying your withdrawal of <?=$currency?>. Please check your email, click on the link in the email to withdraw the <?=$currency?>.</p>
</div>

