<div class="container-fluid" style="text-align:center;margin-top:10px ">
<p  style="background-color:white;padding:2px;width:500px;margin:auto;border:1px solid #dddddd "><strong>Funding USD, EURO or More to Your IBWT Account Via EGOPAY</strong></p><br>
<a href="https://www.egopay.com/personal/what-is-egopay" target="_blank"> <img src="/img/egopay_new_logo1.png" alt="egopay" text="egopay"></a>
<br>
<br>
<div style="background-color:white;padding:6px;width:800px;margin:auto;border:1px solid #dddddd;text-align:center;">
<p>
EgoPay is a global payment processor, which enables you to send money to your friends or family members, fund Forex or Crypto-currency accounts, shop online and even more!
With EgoPay you can reach international companies and feed your ego. Enjoy our convenient system, residual referral system and friendly customer support.
</p>		
</div>

<img src="/img/Stamp.png" alt="IBWT"><br><br>

<div style="background-color:white;padding:2px;width:800px;margin:auto;border:1px solid #dddddd ">
<p>You will to need submit standard information and get a verified account with <a href="https://www.egopay.com/" target="_blank">EGOPAY</a> to transfer funds via a wire transfer.</p>

<p>Once you have your funds in your EGOPAY account, conduct your deposit request via the <a href="/users/funding_fiat">Funding Fiat</a> window, whilst logged into your IBWT account, then send the equal amount of funds to <a href="mailto:deposit@ibwt.co.uk?subject=EGOPAY">deposit@ibwt.co.uk</a> via your <a href="https://www.egopay.com/" target="_blank">EGOPAY</a> account.</p>

<p>The transaction will be verified and your IBWT account will be credited within 24 hours.
IBWT operates this service Monday to Saturday.</p>
<p>You will get an IBWT reference (your account name followed by some numbers) when you make your deposit request on your IBWT account, please make sure you use this when depositing to IBWT via EGOPAY.</p>
<p style="background-color:white;padding:2px;width:500px;margin:auto;border:1px solid #dddddd ">
</p><br><img src="/img/egopay2.png" title="EGOPAY">
</div>