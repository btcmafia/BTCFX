<h4>Password change:</h4>
<?=$msg?>