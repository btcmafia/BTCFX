<div style="background-color:#eeeeee;height:50px;padding-left:20px;padding-top:10px">
	<img src="https://<?=COMPANY_URL?>/img/<?=COMPANY_URL?>.gif" alt="<?=COMPANY_URL?>">
</div>
<p>Please click on this link to change the password!</p>
<p><a href="https://<?=$_SERVER['HTTP_HOST'];?>/users/changepassword/<?=$key?>">https://<?=$_SERVER['HTTP_HOST'];?>/users/changepassword/<?=$key?></a></p>

<p>Thank you,</p>
<p>Support</p>

