<h3>Print / Cold Storage</h3>
<table class="table table-condensed table-bordered table-hover">
	<tr>
	<td>
		<h5>Uses:</h5>
		<ol>
			<li><strong>Security</strong>: As this is an offline virtual currency, it is very safe from the hackers of the internet world.</li>
			<li><strong>Gift</strong>: You can gift these bitcoins to friends, children, grandchildren and make them aware of this new phenomena. Also make their world secure!</li>
			<li><strong>Collectibles</strong>: Use them as collectibles as you collect stamps.</li>
			<li><strong>Transact</strong>: Many non-bitcoiners want bitcoins, but they do not trust it unless they see it and feel it. This is one of the best options for traders who sell BTC off cafes, meeting points. They can show them and give them to the buyer for cash!</li>
			<li><strong>Denominations</strong>: You wallet can be broken to different denominations of safe currency. If you have 100BTC, you can divide them into:
			<ul>
				<li>1 x 50 BTC</li>
				<li>1 x 20 BTC</li>
				<li>1 x 10 BTC</li>
				<li>1 x 5 BTC</li>
				<li>1 x 2 BTC</li>
				<li>5 x 1 BTC</li>
				<li>10 x 0.1 BTC</li>
				<li>20 x 0.2 BTC</li>
				<li>10 x 0.5 BTC</li>
			</ul>
			These can be used as a normal currency when you need to spend it. You will not expose your main wallet to the world.
			</li>
		</ol>
<h5>Sample</h5>
<img src="/img/bitcoin-ibwt.jpg" width="800" style="padding:5px ">
<h5>Security</h5>
<p>In Bitcoin We Trust, while generating the print, we do not store any keys on the server, the file is processed in RAM and delivered securely to your email address.</p>
<h5>Fees</h5>
<p>This service is free!</p>
<h5>How to get them</h5>
<a href="/print/cold" class="btn btn-primary">Get your print!</a>	
	</td>
	</tr>
</table>