<div style="background-image:url(/img/Stamp.png);background-position:bottom right;background-repeat:no-repeat">
<div class="row container" >
	<div class="span12">
		<div class="navbar">
			<div class="navbar-inner1">
				<a class="brand" href="#"><?=$t('Print / Cold storage')?> </a>
			</div>
		</div>
		<table class="table table-condensed table-bordered table-hover" style="margin-top:-20px">
		<tr>
			<td>
<p>Your Print / Cold storage PDF is ready for download. </p>
<p>Click on the link below to download the file directly in your browser. You should print ONLY, it is not advisable to save to the file to the computer.</p>
<p>The file is automatically deleted on the server.</p>

			</td>
		</tr>
			<tr>
				<td>
					<a href="/vanity/out/ibwt-Print-<?=$data[0]['address']?>.pdf" target="_blank">Your print / cold storage</a>
				</td>
			</tr>
		</table>
	</div>
</div><br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</div>