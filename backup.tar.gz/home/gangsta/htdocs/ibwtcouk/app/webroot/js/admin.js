	$('#alert').hide();		
	$('#StartDate').datepicker();
	$('#EndDate').datepicker();	
